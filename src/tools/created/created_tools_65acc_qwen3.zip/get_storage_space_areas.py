
import ifcopenshell
import ifcopenshell.util.element
from typing import List, Dict, Union

def get_storage_space_areas(ifc_file_path: str, storage_keywords: List[str] = None) -> Dict[str, Union[int, float]]:
    """
    Identifies storage spaces in an IFC model and calculates their total area.
    
    Args:
        ifc_file_path (str): Path to the IFC file
        storage_keywords (List[str], optional): Keywords to identify storage spaces.
            Defaults to common storage-related terms.
            
    Returns:
        Dict[str, Union[int, float]]: Dictionary containing:
            - 'count': Number of storage spaces identified
            - 'total_area': Total area of all storage spaces
            - 'areas': List of individual space areas
            
    Note:
        This function works with IFC models that follow Revit conventions with 
        property sets like 'PSet_Revit_Identity Data' and 'PSet_Revit_Dimensions'.
        Storage spaces are identified by keywords in their names or category codes.
    """
    
    # Default storage keywords if none provided
    if storage_keywords is None:
        storage_keywords = [
            'storage', 'store', 'warehouse', 'closet', 'locker', 'utility', 
            'mechanical', 'electrical', 'plumbing', 'trash', 'janitor', 'soil',
            'hazard', 'equip', 'pharm', 'receiving', 'mech'
        ]
    
    # Load the IFC model
    try:
        model = ifcopenshell.open(ifc_file_path)
    except Exception as e:
        return {
            "count": 0,
            "total_area": 0.0,
            "areas": [],
            "error": f"Failed to load IFC model: {str(e)}"
        }
    
    # Get all IfcSpace elements
    spaces = model.by_type("IfcSpace")
    
    storage_spaces = []
    storage_areas = []
    
    # Process each space to identify storage spaces
    for space in spaces:
        # Get properties of this space
        properties = ifcopenshell.util.element.get_psets(space)
        
        # Check name, description, and object type
        space_name = (space.Name or "").lower()
        space_description = (space.Description or "").lower()
        space_object_type = (space.ObjectType or "").lower()
        
        # Check for storage keywords in name, description, or object type
        is_storage = any(keyword in space_name for keyword in storage_keywords) or                      any(keyword in space_description for keyword in storage_keywords) or                      any(keyword in space_object_type for keyword in storage_keywords)
        
        # Also check property sets for storage-related information
        if not is_storage:
            for pset_name, pset_dict in properties.items():
                if 'identity' in pset_name.lower() or 'category' in pset_name.lower() or 'name' in pset_name.lower():
                    for key, value in pset_dict.items():
                        if isinstance(value, str):
                            if any(keyword in value.lower() for keyword in storage_keywords):
                                is_storage = True
                                break
                            # Check for specific category codes that indicate storage
                            elif '13-75' in value or '13-81' in value:  # Storage or equipment rooms
                                is_storage = True
                                break
                    if is_storage:
                        break
        
        # If identified as storage space, extract area
        if is_storage:
            storage_spaces.append(space)
            area = None
            
            # Try to get area from various property sets
            for pset_name, pset_dict in properties.items():
                if 'area' in pset_name.lower() or 'dimension' in pset_name.lower():
                    for key, value in pset_dict.items():
                        if 'area' in key.lower() and isinstance(value, (int, float)):
                            area = float(value)
                            break
                if area is not None:
                    break
            
            # If no area found, try to get from GSA Space Areas
            if area is None:
                gsa_areas = properties.get('GSA Space Areas', {})
                for key, value in gsa_areas.items():
                    if 'area' in key.lower() and isinstance(value, (int, float)):
                        area = float(value)
                        break
            
            # If still no area, try to get from Revit Dimensions
            if area is None:
                revit_dims = properties.get('PSet_Revit_Dimensions', {})
                for key, value in revit_dims.items():
                    if 'area' in key.lower() and isinstance(value, (int, float)):
                        area = float(value)
                        break
            
            storage_areas.append(area if area is not None else 0.0)
    
    # Calculate results
    total_area = sum(area for area in storage_areas if area is not None)
    
    return {
        "count": len(storage_spaces),
        "total_area": round(total_area, 2),
        "areas": [round(area, 2) if area is not None else 0.0 for area in storage_areas],
        "spaces_identified": len(storage_spaces)
    }
