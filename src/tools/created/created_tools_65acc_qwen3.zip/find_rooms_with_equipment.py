
import ifcopenshell
import ifcopenshell.util.element
import ifcopenshell.util.shape
import ifcopenshell.util.placement
import ifcopenshell.util.geolocation
import ifcopenshell.util.system
import ifcopenshell.geom
import math
import json
from typing import List, Dict, Any

def find_rooms_with_equipment(ifc_file_path: str, equipment_pattern: str) -> List[Dict[str, Any]]:
    """
    Identifies rooms/spaces containing specific types of equipment or devices.
    
    Args:
        ifc_file_path (str): Path to the IFC file
        equipment_pattern (str): Pattern to match equipment types (e.g., 'thermostat', 'sensor', 'control')
        
    Returns:
        List[Dict]: A list of dictionaries containing room information and associated equipment
                    Each dictionary has:
                    - room_name: Name/identifier of the room/space
                    - room_guid: GUID of the room/space
                    - equipment: List of equipment found in the room
        
    Note:
        This function works with equipment identified through IfcDistributionControlElement
        and other IfcElement entities. It uses property sets to identify equipment types,
        particularly focusing on PSet_Revit_Type_Identity Data which contains 'Label' that
        often indicates equipment type. This function is particularly effective with
        IFC models exported from Revit.
    """
    
    # Open the IFC file
    model = ifcopenshell.open(ifc_file_path)
    
    # Find all equipment elements that match the pattern
    equipment_elements = set()  # Use set to avoid duplicates
    
    # Look for distribution control elements (often used for equipment like sensors, controls)
    distribution_elements = model.by_type("IfcDistributionControlElement")
    for element in distribution_elements:
        # Check element name/type for pattern match
        element_name = getattr(element, 'Name', '') or ''
        element_type = getattr(element, 'ObjectType', '') or ''
        
        # Also check property sets for equipment type information
        psets = ifcopenshell.util.element.get_psets(element)
        equipment_type = ""
        
        # Check for Revit type information
        if 'PSet_Revit_Type_Identity Data' in psets:
            type_data = psets['PSet_Revit_Type_Identity Data']
            equipment_type = type_data.get('Label', '')
        
        # Check if pattern matches name, type, or equipment type
        if (equipment_pattern.lower() in element_name.lower() or 
            equipment_pattern.lower() in element_type.lower() or
            equipment_pattern.lower() in equipment_type.lower()):
            equipment_elements.add(element)
    
    # Also check generic elements (but avoid duplicates)
    generic_elements = model.by_type("IfcElement")
    for element in generic_elements:
        # Skip if already processed as distribution element
        if element in equipment_elements:
            continue
            
        # Check element name/type for pattern match
        element_name = getattr(element, 'Name', '') or ''
        element_type = getattr(element, 'ObjectType', '') or ''
        
        # Also check property sets for equipment type information
        psets = ifcopenshell.util.element.get_psets(element)
        equipment_type = ""
        
        # Check for Revit type information
        if 'PSet_Revit_Type_Identity Data' in psets:
            type_data = psets['PSet_Revit_Type_Identity Data']
            equipment_type = type_data.get('Label', '')
            
        # Check if pattern matches name, type, or equipment type
        if (equipment_pattern.lower() in element_name.lower() or 
            equipment_pattern.lower() in element_type.lower() or
            equipment_pattern.lower() in equipment_type.lower()):
            equipment_elements.add(element)
    
    # For each equipment, find which room/space it's in
    room_equipment_map = {}
    
    for equipment in equipment_elements:
        # Get the container (space/room) for this equipment
        container = ifcopenshell.util.element.get_container(equipment)
        
        if container and container.is_a() in ["IfcSpace", "IfcZone"]:
            # Get space/room information
            room_name = getattr(container, 'Name', '') or 'Unknown Room'
            room_guid = getattr(container, 'GlobalId', 'Unknown GUID')
            
            # Create room key for mapping
            room_key = f"{room_name}_{room_guid}"
            
            # Initialize room entry if not exists
            if room_key not in room_equipment_map:
                room_equipment_map[room_key] = {
                    'room_name': room_name,
                    'room_guid': room_guid,
                    'equipment': []
                }
            
            # Add equipment information
            equipment_name = getattr(equipment, 'Name', '') or 'Unnamed Equipment'
            equipment_type = getattr(equipment, 'ObjectType', '') or 'Unknown Type'
            
            # Get additional equipment details from property sets
            psets = ifcopenshell.util.element.get_psets(equipment)
            equipment_details = {
                'name': equipment_name,
                'type': equipment_type,
                'guid': equipment.GlobalId,
                'properties': psets
            }
            
            # Avoid duplicate equipment entries
            existing_equipment = [e for e in room_equipment_map[room_key]['equipment'] 
                                if e['guid'] == equipment.GlobalId]
            if not existing_equipment:
                room_equipment_map[room_key]['equipment'].append(equipment_details)
    
    # Convert to list format for return
    result = list(room_equipment_map.values())
    
    return result
