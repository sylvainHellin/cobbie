
import ifcopenshell
import ifcopenshell.util.element
import ifcopenshell.util.shape
import ifcopenshell.util.placement
import ifcopenshell.util.geolocation
import ifcopenshell.util.system
import ifcopenshell.geom
import math
import json
import re
from typing import *

def get_fire_rating_information(
    ifc_file_path: str,
    element_types: Optional[List[str]] = None,
    fire_rating_property_names: Optional[List[str]] = None,
    search_property_sets: bool = True
) -> Dict[str, Any]:
    """
    Systematically searches an IFC model for fire rating information in building elements.
    
    This function searches for fire rating properties in building elements, with a focus on walls, 
    doors, floors, and ceilings. It checks various property sets and property names that might 
    contain fire rating information and provides a comprehensive report on fire-rated elements found.
    
    The function handles various IFC schema versions and different BIM authoring software 
    conventions for storing fire rating properties. It works with common property sets like:
    - Pset_WallCommon, Pset_DoorCommon, Pset_Flooring, Pset_Ceiling
    - Pset_FireRating, PSet_Revit_Type_Construction
    
    And common property names like:
    - FireRating, FireResistance, Rating, FireRatingPeriod
    - HourRating, FireResistanceRating
    
    Args:
        ifc_file_path (str): Path to the IFC file to analyze
        element_types (List[str], optional): Specific IFC element types to search within.
            If None, search common building element types.
        fire_rating_property_names (List[str], optional): List of specific fire rating property names to look for.
            If None, search for common fire rating property names.
        search_property_sets (bool): Whether to search within property sets for fire rating properties.
            Defaults to True.
            
    Returns:
        Dict[str, Any]: A dictionary containing:
            - 'found_fire_ratings': List of dictionaries with fire rating properties found
            - 'elements_without_fire_data': List of element GUIDs that were checked but had no fire rating properties
            - 'summary': Summary statistics
            - 'recommendations': Suggestions for finding fire rating information if not directly available
    """
    # Default element types to search if none provided
    if element_types is None:
        element_types = ['IfcWall', 'IfcDoor', 'IfcSlab', 'IfcCovering']
    
    # Default fire rating property names if none provided
    if fire_rating_property_names is None:
        fire_rating_property_names = [
            'FireRating', 'FireResistance', 'Rating', 'FireRatingPeriod',
            'HourRating', 'FireResistanceRating', 'FireRatingValue'
        ]
    
    # Common property set names that may contain fire rating information
    fire_rating_pset_names = [
        'Pset_WallCommon', 'Pset_DoorCommon', 'Pset_Flooring', 'Pset_Ceiling',
        'Pset_FireRating', 'PSet_Revit_Type_Construction', 'Pset_BuildingElementCommon',
        'Pset_Construction', 'Pset_SlabCommon', 'Pset_CoveringCommon'
    ]
    
    # Open the IFC file
    ifc_file = ifcopenshell.open(ifc_file_path)
    
    # Initialize result structures
    found_fire_ratings = []
    elements_without_fire_data = []
    
    # Get elements of specified types
    elements_to_check = []
    for element_type in element_types:
        try:
            elements = ifc_file.by_type(element_type)
            elements_to_check.extend(elements)
        except Exception as e:
            # This is expected for some element types that don't exist in certain IFC schemas
            pass
    
    # Process each element
    for element in elements_to_check:
        # Safely get element attributes
        element_guid = getattr(element, 'GlobalId', 'Unknown')
        element_name = getattr(element, 'Name', 'Unknown')
        element_type = element.is_a() if hasattr(element, 'is_a') else 'Unknown'
        
        fire_rating_found = False
        fire_rating_data = {
            'element_guid': element_guid,
            'element_name': element_name,
            'element_type': element_type,
            'fire_rating_properties': {}
        }
        
        # Get all property sets for the element
        if search_property_sets:
            try:
                psets = ifcopenshell.util.element.get_psets(element)
                
                # Check each property set for fire rating properties
                for pset_name, pset_properties in psets.items():
                    # Skip if pset_name is not a string (sometimes it might be an integer ID)
                    if not isinstance(pset_name, str):
                        continue
                    
                    # Check if this is a fire rating related property set
                    is_fire_pset = any(fire_pset.lower() in pset_name.lower() for fire_pset in fire_rating_pset_names)
                    
                    # Check properties in this property set
                    for prop_name, prop_value in pset_properties.items():
                        # Skip if prop_name is not a string
                        if not isinstance(prop_name, str):
                            continue
                            
                        # Check if property name matches fire rating properties
                        is_fire_prop = any(fire_prop.lower() in prop_name.lower() for fire_prop in fire_rating_property_names)
                        
                        # Additional check: if it's a fire rating property, verify the value looks like a fire rating
                        if is_fire_prop:
                            # Check if the value looks like a fire rating (numeric with optional units, or specific rating strings)
                            if is_fire_rating_value(prop_value):
                                fire_rating_data['fire_rating_properties'][f"{pset_name}.{prop_name}"] = prop_value
                                fire_rating_found = True
                            # If it's in a fire-related property set, we'll be more lenient about the value
                            elif is_fire_pset and prop_value is not None and prop_value != "":
                                # Still check that it's not just a boolean or other non-rating value
                                if is_potential_fire_rating_value(prop_value):
                                    fire_rating_data['fire_rating_properties'][f"{pset_name}.{prop_name}"] = prop_value
                                    fire_rating_found = True
                        # If it's in a fire rating property set, check if the property name might be related to fire ratings
                        elif is_fire_pset:
                            # Check if property name might contain fire rating information
                            prop_name_lower = prop_name.lower()
                            if any(keyword in prop_name_lower for keyword in ['fire', 'rating', 'resistance']):
                                if is_fire_rating_value(prop_value) or is_potential_fire_rating_value(prop_value):
                                    fire_rating_data['fire_rating_properties'][f"{pset_name}.{prop_name}"] = prop_value
                                    fire_rating_found = True
            except Exception as e:
                # Silently handle errors in property set processing to avoid cluttering output
                pass
        
        # If we found fire rating data, add it to our results
        if fire_rating_found:
            found_fire_ratings.append(fire_rating_data)
        else:
            elements_without_fire_data.append(element_guid)
    
    # Prepare summary statistics
    summary = {
        'total_elements_checked': len(elements_to_check),
        'elements_with_fire_ratings': len(found_fire_ratings),
        'elements_without_fire_data': len(elements_without_fire_data),
        'fire_rating_property_names_searched': fire_rating_property_names,
        'element_types_searched': element_types
    }
    
    # Prepare recommendations
    recommendations = []
    if len(found_fire_ratings) == 0:
        recommendations.append("No fire rating properties found. Consider checking:")
        recommendations.append("- If the model contains fire rating information in a different format")
        recommendations.append("- If fire rating information is stored in element descriptions or names")
        recommendations.append("- If fire rating information is stored in external documents or databases")
        recommendations.append("- Expanding the search to include all element types in the model")
    else:
        recommendations.append(f"Found {len(found_fire_ratings)} elements with potential fire rating information.")
        recommendations.append("Review the found fire ratings to verify they contain actual fire rating values.")
        recommendations.append("Some elements may have placeholder values like 'Fire Rating' instead of specific ratings.")
    
    recommendations.append("")
    recommendations.append("Common property set names that may contain fire rating information include:")
    recommendations.append("- Pset_WallCommon, Pset_DoorCommon, Pset_Flooring, Pset_Ceiling")
    recommendations.append("- Pset_FireRating, PSet_Revit_Type_Construction")
    
    recommendations.append("")
    recommendations.append("Common property names for fire ratings include:")
    recommendations.append("- FireRating, FireResistance, Rating, FireRatingPeriod")
    recommendations.append("- HourRating, FireResistanceRating")
    
    # Additional recommendations based on findings
    if len(found_fire_ratings) > 0:
        recommendations.append("")
        recommendations.append("Additional suggestions:")
        recommendations.append("- Check element names and descriptions for fire rating information")
        recommendations.append("- Verify that found fire ratings are specific values (e.g., '60 minutes', '1 hour') rather than generic placeholders")
        recommendations.append("- Consider checking the model's documentation or specifications for fire rating information")
    
    # Return the complete result
    return {
        'found_fire_ratings': found_fire_ratings,
        'elements_without_fire_data': elements_without_fire_data,
        'summary': summary,
        'recommendations': recommendations
    }

def is_fire_rating_value(value) -> bool:
    """
    Check if a value looks like a fire rating value.
    Fire ratings are typically numeric (30, 60, 90, 120, 180 minutes) or 
    string representations like "1h", "2hr", "90min", etc.
    """
    if value is None:
        return False
    
    # Convert to string for checking
    str_value = str(value).strip().lower()
    
    # Check for common fire rating patterns
    fire_rating_patterns = [
        r'^\d+\s*(min|minute|minutes|mins)?$',  # Numbers with optional minute units
        r'^\d+\.?\d*\s*(h|hr|hour|hours)$',     # Numbers with hour units
        r'^[0-9]+(/[0-9]+)?$',                   # Simple fractions or numbers
        r'^(1|2|3|4|5|6)\s*-?\s*(hour|hr|h)$',  # Common hour ratings
        r'^(30|60|90|120|180|240)\s*$',         # Common minute ratings
    ]
    
    for pattern in fire_rating_patterns:
        if re.match(pattern, str_value):
            return True
    
    # Check for specific fire rating strings
    fire_rating_strings = [
        '1 hour', '2 hour', '3 hour', '4 hour',
        '30 min', '60 min', '90 min', '120 min', '180 min',
        '1hr', '2hr', '3hr', '4hr',
        '30min', '60min', '90min', '120min', '180min',
        '1h', '2h', '3h', '4h'
    ]
    
    return str_value in fire_rating_strings

def is_potential_fire_rating_value(value) -> bool:
    """
    More lenient check for potential fire rating values.
    """
    if value is None:
        return False
    
    # Exclude obvious non-rating values
    if isinstance(value, bool):
        return False
    
    # For strings, check if they contain fire rating indicators
    str_value = str(value).strip().lower()
    
    # Exclude very short strings that are likely not ratings
    if len(str_value) < 2:
        return False
    
    # Exclude common non-rating values
    non_rating_values = ['true', 'false', 'yes', 'no', 'n/a', 'na', 'none', 'unknown']
    if str_value in non_rating_values:
        return False
    
    # If it's a longer string, it might be a fire rating description
    if len(str_value) > 10:
        fire_keywords = ['fire', 'rating', 'resistance', 'hour', 'minute', 'min', 'hr', 'h']
        return any(keyword in str_value for keyword in fire_keywords)
    
    return True
