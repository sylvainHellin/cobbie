import ifcopenshell
import ifcopenshell.util.element
from typing import List, Dict, Any, Optional

def find_space_by_function(model: ifcopenshell.file, keywords: str, building_storey: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Find spaces in an IFC model based on functional descriptions or keywords.
    
    This function searches across space names, numbers, and property sets to find spaces
    that match the given keywords. It handles partial matches and case-insensitive search.
    Results can be filtered by building storey/level.
    
    The function addresses issues with rigid search logic by:
    - Searching across all property set values, not just space names
    - Handling partial matches (e.g., finding "TECH. OFFICE" when searching for "tech office")
    - Supporting multi-word keyword searches
    - Allowing optional building storey filtering
    - Better distinguishing between actual laboratory spaces and related spaces
    
    Args:
        model (ifcopenshell.file): The IFC model to search in
        keywords (str): Keywords to search for (e.g., "tech office")
        building_storey (Optional[str]): Optional building storey name to filter results
        
    Returns:
        List[Dict[str, Any]]: List of matching spaces with their information including:
            - global_id: Space GlobalId
            - name: Space name
            - number: Space number
            - description: Space description
            - building_storey: Associated building storey
            - area: Space area (if available, typically from PSet_Revit_Dimensions)
            - volume: Space volume (if available, typically from PSet_Revit_Dimensions)
            - properties: All property sets of the space
    
    Example:
        >>> model = ifcopenshell.open("model.ifc")
        >>> spaces = find_space_by_function(model, "waiting room", "First Floor")
        >>> print(spaces[0]['name'])
        'CENTRAL WAITING'
        
        >>> # This will find spaces like "TECH. OFFICE" that previous rigid search missed
        >>> tech_spaces = find_space_by_function(model, "tech office")
    """
    # Normalize keywords for case-insensitive search
    keywords_lower = keywords.lower().strip()
    
    # Get all spaces in the model
    all_spaces = model.by_type("IfcSpace")
    
    matching_spaces = []
    
    for space in all_spaces:
        # Get space basic information
        space_info = {
            "global_id": space.GlobalId,
            "name": space.Name or "",
            "number": "",
            "description": space.Description or "",
            "building_storey": "",
            "area": None,
            "volume": None,
            "properties": {}
        }
        
        # Get properties
        properties = ifcopenshell.util.element.get_psets(space)
        space_info["properties"] = properties
        
        # Get building storey information
        # First try the ContainedInStructure relationship
        if hasattr(space, 'ContainedInStructure') and space.ContainedInStructure:
            for rel in space.ContainedInStructure:
                if rel.RelatingStructure.is_a("IfcBuildingStorey"):
                    space_info["building_storey"] = rel.RelatingStructure.Name or ""
                    break
        
        # If that didn't work, try getting it from PSet_Revit_Constraints
        if not space_info["building_storey"] and "PSet_Revit_Constraints" in properties:
            constraints = properties["PSet_Revit_Constraints"]
            if "Level" in constraints:
                space_info["building_storey"] = constraints["Level"]
        
        # Extract number and area/volume from properties if available
        if "PSet_Revit_Identity Data" in properties:
            identity_data = properties["PSet_Revit_Identity Data"]
            if "Number" in identity_data:
                space_info["number"] = identity_data["Number"]
        
        if "PSet_Revit_Dimensions" in properties:
            dimensions = properties["PSet_Revit_Dimensions"]
            if "Area" in dimensions:
                space_info["area"] = dimensions["Area"]
            if "Volume" in dimensions:
                space_info["volume"] = dimensions["Volume"]
        
        # Check if this space matches our search criteria
        search_fields = [
            space_info["name"],
            space_info["number"],
            space_info["description"],
            space_info["building_storey"]
        ]
        
        # Add property set values to search fields
        for pset_name, pset_dict in properties.items():
            for prop_name, prop_value in pset_dict.items():
                if prop_name != "id":  # Skip the id field
                    search_fields.append(str(prop_value))
        
        # Combine all search fields into one string for matching
        combined_text = " ".join(search_fields).lower()
        
        # Special handling for laboratory searches
        is_lab_search = "lab" in keywords_lower
        is_actual_lab = False
        
        # Check if this is actually a laboratory space by checking OmniClass category
        if "PSet_Revit_Identity Data" in properties:
            identity_props = properties["PSet_Revit_Identity Data"]
            if "OmniClass Table 13 Category" in identity_props:
                omni_class = str(identity_props["OmniClass Table 13 Category"]).lower()
                if "laboratory" in omni_class:
                    is_actual_lab = True
        
        # If we're searching for labs, only include actual labs
        if is_lab_search and not is_actual_lab:
            # Also check if "lab" is in the name for additional verification
            if "lab" in space_info["name"].lower():
                # Check if it's a lab-related office that shouldn't be counted as a true lab
                name_lower = space_info["name"].lower()
                if "office" in name_lower or "storage" in name_lower or "prep" in name_lower:
                    # This is likely not a true laboratory requiring specialty flooring
                    is_actual_lab = False
                else:
                    # It's a lab by name and not explicitly an office/storage/prep area
                    is_actual_lab = True
        
        # Check if keywords match (supporting multi-word searches)
        keyword_matches = True
        
        # If keywords were provided, check if they match
        if keywords_lower:
            # For lab searches, we need to match actual labs
            if is_lab_search:
                keyword_matches = is_actual_lab
            else:
                # For other searches, check if all keywords are present
                keyword_matches = all(keyword in combined_text for keyword in keywords_lower.split())
        else:
            # If no keywords provided, include all spaces (but still apply storey filter)
            keyword_matches = True
        
        # Check if building storey filter matches (if specified)
        storey_matches = True
        if building_storey and building_storey.lower() not in space_info["building_storey"].lower():
            storey_matches = False
        
        # If both keyword and storey filters match, add to results
        if keyword_matches and storey_matches:
            matching_spaces.append(space_info)
    
    return matching_spaces