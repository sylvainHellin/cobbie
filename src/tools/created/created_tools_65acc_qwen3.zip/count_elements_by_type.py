
import ifcopenshell
import ifcopenshell.util.element
import ifcopenshell.util.shape
import ifcopenshell.util.placement
import ifcopenshell.util.geolocation
import ifcopenshell.util.system
import ifcopenshell.geom
import math
import json
from typing import *


def count_elements_by_type(ifc_file_path: str, ifc_type: str, return_elements: bool = False) -> Union[int, Tuple[int, list]]:
    """
    Count the number of elements of a specified IFC type in an IFC model.
    
    Args:
        ifc_file_path (str): Path to the IFC file.
        ifc_type (str): The IFC element type to count (e.g., 'IfcWindow', 'IfcDoor').
        return_elements (bool): If True, also return the list of elements found.
        
    Returns:
        int: The count of elements found (if return_elements is False).
        Tuple[int, list]: A tuple containing the count and list of elements (if return_elements is True).
        
    Raises:
        FileNotFoundError: If the IFC file is not found.
        Exception: If there's an error reading the IFC file or if the IFC type is invalid.
        
    Example:
        count = count_elements_by_type("model.ifc", "IfcWindow")
        count, elements = count_elements_by_type("model.ifc", "IfcDoor", return_elements=True)
    """
    try:
        # Try to open the IFC file
        ifc_file = ifcopenshell.open(ifc_file_path)
    except FileNotFoundError:
        raise FileNotFoundError(f"IFC file not found: {{ifc_file_path}}")
    except Exception as e:
        raise Exception(f"Error reading IFC file: {{str(e)}}")
    
    try:
        # Get elements of the specified type
        elements = ifc_file.by_type(ifc_type)
    except Exception as e:
        raise Exception(f"Error retrieving elements of type {{ifc_type}}: {{str(e)}}")
    
    # Count the elements
    count = len(elements)
    
    # Return the count and optionally the elements
    if return_elements:
        return count, elements
    else:
        return count
