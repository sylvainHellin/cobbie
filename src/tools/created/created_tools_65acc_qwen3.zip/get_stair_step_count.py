
import ifcopenshell
import ifcopenshell.util.element
from typing import List, Dict, Any, Optional

def get_stair_step_count(
    ifc_file_path: str,
    stair_identifier: Optional[str] = None,
    include_spatial_info: bool = False
) -> List[Dict[str, Any]]:
    """
    Retrieves the number of steps (risers) in stair elements from an IFC model.
    
    This function extracts step count information from both IfcStair and IfcStairFlight elements.
    It looks for the NumberOfRiser property in Pset_StairCommon (for IfcStair) and 
    Pset_StairFlightCommon (for IfcStairFlight) property sets.
    
    Note: This function assumes the IFC model follows standard property set conventions.
    For models exported from specific BIM authoring software (e.g., Revit), additional
    property sets may contain step count information.
    
    Args:
        ifc_file_path (str): Path to the IFC file
        stair_identifier (Optional[str]): Name, GlobalId, or identifier of specific stair to query (if None, return all stairs)
        include_spatial_info (bool, optional): Whether to include spatial container information (default: False)
        
    Returns:
        List[Dict[str, Any]]: List of dictionaries containing stair information:
          - stair_name: Name of the stair element
          - stair_guid: GlobalId of the stair element
          - stair_type: IFC type (IfcStair or IfcStairFlight)
          - step_count: Number of steps/risers (int) or None if not found
          - property_set_name: Name of the property set where step count was found or None if not found
          - spatial_info: Dictionary with spatial container information (if requested and available)
          
    Raises:
        FileNotFoundError: If the IFC file cannot be found
        Exception: If there are issues reading the IFC file
    """
    try:
        # Load the IFC file
        ifc_file = ifcopenshell.open(ifc_file_path)
    except FileNotFoundError:
        raise FileNotFoundError(f"IFC file not found: {ifc_file_path}")
    except Exception as e:
        raise Exception(f"Error opening IFC file: {str(e)}")
    
    # Find all stair elements
    stair_elements = ifc_file.by_type("IfcStair")
    stair_flight_elements = ifc_file.by_type("IfcStairFlight")
    
    # Combine all stair-related elements
    all_stair_elements = stair_elements + stair_flight_elements
    
    # Filter by identifier if specified
    if stair_identifier:
        filtered_elements = []
        for element in all_stair_elements:
            # Check if identifier matches Name or GlobalId
            if (element.Name and stair_identifier in element.Name) or element.GlobalId == stair_identifier:
                filtered_elements.append(element)
        all_stair_elements = filtered_elements
    
    results = []
    
    # Process each stair element
    for element in all_stair_elements:
        stair_info = {
            "stair_name": element.Name or "Unnamed",
            "stair_guid": element.GlobalId,
            "stair_type": element.is_a(),
            "step_count": None,
            "property_set_name": None,
            "spatial_info": None
        }
        
        # Get property sets for the element
        try:
            psets = ifcopenshell.util.element.get_psets(element)
        except Exception as e:
            # If we can't get property sets, continue with None values
            psets = {}
        
        # Look for step count in relevant property sets
        step_count = None
        property_set_name = None
        
        # Check for IfcStair elements
        if element.is_a("IfcStair"):
            # Look in Pset_StairCommon
            if "Pset_StairCommon" in psets and "NumberOfRiser" in psets["Pset_StairCommon"]:
                step_count = psets["Pset_StairCommon"]["NumberOfRiser"]
                property_set_name = "Pset_StairCommon"
        
        # Check for IfcStairFlight elements
        elif element.is_a("IfcStairFlight"):
            # Look in Pset_StairFlightCommon
            if "Pset_StairFlightCommon" in psets and "NumberOfRiser" in psets["Pset_StairFlightCommon"]:
                step_count = psets["Pset_StairFlightCommon"]["NumberOfRiser"]
                property_set_name = "Pset_StairFlightCommon"
        
        stair_info["step_count"] = step_count
        stair_info["property_set_name"] = property_set_name
        
        # Include spatial information if requested
        if include_spatial_info:
            try:
                spatial_elements = ifcopenshell.util.element.get_referenced_structures(element)
                spatial_info = []
                for spatial_element in spatial_elements:
                    spatial_info.append({
                        "name": spatial_element.Name or "Unnamed",
                        "guid": spatial_element.GlobalId,
                        "type": spatial_element.is_a()
                    })
                stair_info["spatial_info"] = spatial_info if spatial_info else None
            except Exception:
                # If we can't get spatial information, leave as None
                stair_info["spatial_info"] = None
        
        results.append(stair_info)
    
    return results
