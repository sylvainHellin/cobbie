import ifcopenshell
import ifcopenshell.util.element
from typing import List

def get_external_wall_thickness_by_type(ifc_file_path: str, wall_type_pattern: str, dimension_name: str = 'Width') -> List[float]:
    """
    Get thickness values of external walls filtered by type pattern.
    
    This function identifies external walls in an IFC model and filters them by a name pattern
    to distinguish between different types of external walls (e.g., main exterior walls, 
    party walls, foundation walls). It then extracts thickness/width properties from the 
    appropriate property sets (PSet_Revit_Type_Construction.Width).
    
    Args:
        ifc_file_path (str): Path to the IFC file
        wall_type_pattern (str): Pattern to match against wall names to filter specific wall types
        dimension_name (str): Name of the dimension property to extract (default: 'Width')
    
    Returns:
        List[float]: List of thickness values for the matching external walls
        
    Example:
        >>> thicknesses = get_external_wall_thickness_by_type("model.ifc", "Exterior - Brick on Block")
        >>> print(thicknesses)
        [0.417, 0.417]
    """
    # Load the IFC file
    ifc_file = ifcopenshell.open(ifc_file_path)
    
    # Get all walls
    all_walls = ifc_file.by_type("IfcWall")
    
    # Filter for external walls and walls matching the type pattern
    matching_walls = []
    for wall in all_walls:
        # Check if wall is external
        pset_common = ifcopenshell.util.element.get_pset(wall, "Pset_WallCommon")
        is_external = pset_common.get("IsExternal") if pset_common else False
        
        # Check if wall name matches the pattern
        wall_name = wall.Name if wall.Name else ""
        matches_pattern = wall_type_pattern in wall_name
        
        if is_external and matches_pattern:
            matching_walls.append(wall)
    
    # Extract thickness values
    thickness_values = []
    for wall in matching_walls:
        # Try to get the dimension from PSet_Revit_Type_Construction first
        pset_construction = ifcopenshell.util.element.get_pset(wall, "PSet_Revit_Type_Construction")
        if pset_construction and dimension_name in pset_construction:
            thickness_values.append(float(pset_construction[dimension_name]))
            continue
            
        # If not found, try other common property sets
        all_psets = ifcopenshell.util.element.get_psets(wall)
        for pset_name, pset_dict in all_psets.items():
            if dimension_name in pset_dict:
                thickness_values.append(float(pset_dict[dimension_name]))
                break
    
    return thickness_values