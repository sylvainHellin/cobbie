
import ifcopenshell
import ifcopenshell.util.element
from typing import List, Dict, Any, Optional

def count_building_hardware_components(
    ifc_file_path: str,
    component_keywords: List[str],
    element_types: Optional[List[str]] = None,
    case_sensitive: bool = False,
    include_property_search: bool = True
) -> Dict[str, Any]:
    """
    Count building hardware components in an IFC model using flexible name pattern matching.
    
    This tool searches for building hardware components that are typically not explicitly 
    modeled as separate IFC entities. It uses flexible name pattern matching to identify 
    potential hardware components and checks multiple IFC element types that might represent 
    hardware (IfcDiscreteAccessory, IfcBuildingElementPart, IfcFurnishingElement, etc.).
    
    Assumptions:
    - Hardware components may be represented as various IFC element types
    - Hardware names may appear in element names or property sets
    - Property sets may follow software-specific naming conventions (e.g., PSet_Revit_*)
    
    Args:
        ifc_file_path (str): Path to the IFC file
        component_keywords (List[str]): List of keywords to search for (e.g., ['doorknob', 'handle', 'hinge', 'knob'])
        element_types (List[str], optional): Specific IFC element types to search within. 
            If None, searches common hardware element types: ['IfcDiscreteAccessory', 'IfcBuildingElementPart', 
            'IfcFurnishingElement', 'IfcElementAssembly', 'IfcFastener', 'IfcMechanicalFastener']
        case_sensitive (bool, optional): Whether to perform case-sensitive matching (default: False)
        include_property_search (bool, optional): Whether to search within property sets (default: True)
        
    Returns:
        Dict[str, Any]: Dictionary containing:
            - 'count': Total number of hardware components found
            - 'by_keyword': Dictionary with counts for each keyword
            - 'by_type': Dictionary with counts for each IFC element type
            - 'elements': List of found elements with their names, types, and GlobalIds
            - 'confidence': Overall confidence score for the results (0-1)
            - 'message': Informative message about the search results and limitations
    """
    # Default element types to search if none provided
    if element_types is None:
        element_types = [
            'IfcDiscreteAccessory', 'IfcBuildingElementPart', 'IfcFurnishingElement',
            'IfcElementAssembly', 'IfcFastener', 'IfcMechanicalFastener'
        ]
    
    # Prepare keywords based on case sensitivity
    search_keywords = component_keywords if case_sensitive else [kw.lower() for kw in component_keywords]
    
    # Initialize results
    found_elements = []
    keyword_counts = {kw: 0 for kw in component_keywords}
    type_counts = {et: 0 for et in element_types}
    total_count = 0
    
    # Open IFC file
    try:
        ifc_file = ifcopenshell.open(ifc_file_path)
    except Exception as e:
        return {
            'count': 0,
            'by_keyword': {},
            'by_type': {},
            'elements': [],
            'confidence': 0.0,
            'message': f"Error opening IFC file: {str(e)}"
        }
    
    # Search through specified element types
    for element_type in element_types:
        try:
            elements = ifc_file.by_type(element_type)
        except Exception:
            # Element type might not exist in this schema
            continue
            
        for element in elements:
            element_found = False
            matched_keywords = []
            
            # Check element name
            element_name = getattr(element, 'Name', '') or ''
            search_name = element_name if case_sensitive else element_name.lower()
            
            for i, keyword in enumerate(search_keywords):
                original_keyword = component_keywords[i]
                if keyword in search_name:
                    element_found = True
                    if original_keyword not in matched_keywords:
                        matched_keywords.append(original_keyword)
                        keyword_counts[original_keyword] += 1
            
            # Check property sets if enabled
            if include_property_search and not element_found:
                try:
                    psets = ifcopenshell.util.element.get_psets(element)
                    for pset_name, pset_dict in psets.items():
                        # Skip the 'id' field in pset
                        for prop_name, prop_value in pset_dict.items():
                            if prop_name == 'id':
                                continue
                                
                            # Check property name
                            search_prop_name = prop_name if case_sensitive else prop_name.lower()
                            for i, keyword in enumerate(search_keywords):
                                original_keyword = component_keywords[i]
                                if keyword in search_prop_name:
                                    element_found = True
                                    if original_keyword not in matched_keywords:
                                        matched_keywords.append(original_keyword)
                                        keyword_counts[original_keyword] += 1
                            
                            # Check property value if it's a string
                            if isinstance(prop_value, str):
                                search_prop_value = prop_value if case_sensitive else prop_value.lower()
                                for i, keyword in enumerate(search_keywords):
                                    original_keyword = component_keywords[i]
                                    if keyword in search_prop_value:
                                        element_found = True
                                        if original_keyword not in matched_keywords:
                                            matched_keywords.append(original_keyword)
                                            keyword_counts[original_keyword] += 1
                except Exception:
                    # Skip property set analysis for this element if there's an error
                    pass
            
            # If element matches any keyword, add to results
            if element_found:
                total_count += 1
                type_counts[element_type] = type_counts.get(element_type, 0) + 1
                
                found_elements.append({
                    'name': element_name,
                    'type': element.is_a(),
                    'global_id': getattr(element, 'GlobalId', ''),
                    'matched_keywords': matched_keywords
                })
    
    # Calculate confidence score
    # Confidence is based on how many different keywords and types we found
    unique_keywords_found = sum(1 for count in keyword_counts.values() if count > 0)
    unique_types_found = sum(1 for count in type_counts.values() if count > 0)
    
    max_possible_keywords = len(component_keywords)
    max_possible_types = len(element_types)
    
    keyword_coverage = unique_keywords_found / max_possible_keywords if max_possible_keywords > 0 else 0
    type_coverage = unique_types_found / max_possible_types if max_possible_types > 0 else 0
    
    confidence = (keyword_coverage + type_coverage) / 2 if (keyword_coverage + type_coverage) > 0 else 0
    
    # Generate informative message
    if total_count == 0:
        message = "No hardware components found. This could be because: 1) Hardware components are not explicitly modeled in this IFC file, 2) Hardware components use different naming conventions, or 3) Hardware components are part of other elements rather than separate entities."
    else:
        message = f"Found {total_count} potential hardware components. Note that identification is based on keyword matching in element names and property sets, which may not be completely accurate. Review the identified elements to confirm they represent actual hardware components."
    
    return {
        'count': total_count,
        'by_keyword': keyword_counts,
        'by_type': type_counts,
        'elements': found_elements,
        'confidence': confidence,
        'message': message
    }
