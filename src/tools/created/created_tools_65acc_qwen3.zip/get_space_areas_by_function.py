
import ifcopenshell
import ifcopenshell.util.element
from typing import List, Dict, Any

def get_space_areas_by_function(ifc_file_path: str, function_keywords: List[str]) -> Dict[str, Any]:
    """
    Extract area properties from IfcSpace elements based on functional keywords.
    
    This function searches for IfcSpace elements in an IFC model that match the provided
    functional keywords and extracts their area properties. It handles various property
    set conventions including PSet_Revit_Dimensions.Area and GSA Space Areas.GSA BIM Area.
    
    Args:
        ifc_file_path (str): Path to the IFC file
        function_keywords (List[str]): List of keywords to match against space functions
        
    Returns:
        Dict[str, Any]: A dictionary containing:
            - 'spaces': List of dictionaries with space information (name, area, function)
            - 'total_area': Total area of all matching spaces
            - 'count': Number of matching spaces
            
    Note:
        This function assumes the IFC model follows common property set conventions:
        - PSet_Revit_Dimensions.Area (for Revit-exported IFCs)
        - GSA Space Areas.GSA BIM Area (for GSA-compliant models)
        - Pset_SpaceCommon.Area (for standard IFC property sets)
        
        For Revit models, function matching is typically done against:
        - PSet_Revit_Other.Category Description
        - PSet_Revit_Identity Data.OmniClass Table 13 Category
    """
    
    # Load the IFC file
    ifc_file = ifcopenshell.open(ifc_file_path)
    
    # Get all IfcSpace elements
    spaces = ifc_file.by_type("IfcSpace")
    
    matching_spaces = []
    total_area = 0.0
    
    # Convert keywords to lowercase for case-insensitive matching
    keywords_lower = [keyword.lower() for keyword in function_keywords]
    
    for space in spaces:
        # Get space name and description
        space_name = getattr(space, 'Name', '') or ''
        space_description = getattr(space, 'Description', '') or ''
        space_long_name = getattr(space, 'LongName', '') or ''
        
        # Get all property sets for this space
        psets = ifcopenshell.util.element.get_psets(space)
        
        # Check if space matches any of the functional keywords
        is_match = False
        space_function = ""
        
        # Check in space name, description, and long name
        check_fields = [space_name, space_description, space_long_name]
        
        # Also check in property set values, prioritizing function/category properties
        function_properties = []
        for pset_name, pset_dict in psets.items():
            for prop_name, prop_value in pset_dict.items():
                if prop_name != 'id':  # Skip the 'id' field
                    # Collect function/category properties specifically
                    if 'function' in prop_name.lower() or 'category' in prop_name.lower():
                        function_properties.append(str(prop_value))
                    # Add all properties to check_fields for keyword matching
                    check_fields.append(str(prop_value))
        
        # Check if any keyword matches any field
        for field in check_fields:
            field_lower = field.lower()
            for keyword in keywords_lower:
                if keyword in field_lower:
                    is_match = True
                    # If we haven't found a specific function property, use the matching field
                    if not space_function:
                        space_function = field
                    break
            if is_match:
                break
        
        # If we found specific function properties, use those instead
        if function_properties:
            space_function = "; ".join(function_properties)
        
        # If space matches, extract area information
        if is_match:
            area = 0.0
            
            # Look for area in various property sets, following a priority order
            # 1. PSet_Revit_Dimensions.Area (common in Revit models)
            if 'PSet_Revit_Dimensions' in psets and 'Area' in psets['PSet_Revit_Dimensions']:
                try:
                    area = float(psets['PSet_Revit_Dimensions']['Area'])
                except (ValueError, TypeError):
                    pass
            # 2. GSA Space Areas.GSA BIM Area (GSA-compliant models)
            elif 'GSA Space Areas' in psets and 'GSA BIM Area' in psets['GSA Space Areas']:
                try:
                    area = float(psets['GSA Space Areas']['GSA BIM Area'])
                except (ValueError, TypeError):
                    pass
            # 3. Pset_SpaceCommon.Area (standard IFC property sets)
            elif 'Pset_SpaceCommon' in psets and 'Area' in psets['Pset_SpaceCommon']:
                try:
                    area = float(psets['Pset_SpaceCommon']['Area'])
                except (ValueError, TypeError):
                    pass
            # 4. Check for any property set containing 'Area'
            else:
                for pset_name, pset_dict in psets.items():
                    for prop_name, prop_value in pset_dict.items():
                        if 'area' in prop_name.lower() and prop_name != 'id':
                            try:
                                area = float(prop_value)
                                break
                            except (ValueError, TypeError):
                                continue
                    if area > 0:
                        break
            
            space_info = {
                'name': space_name,
                'area': area,
                'function': space_function
            }
            
            matching_spaces.append(space_info)
            total_area += area
    
    return {
        'spaces': matching_spaces,
        'total_area': total_area,
        'count': len(matching_spaces)
    }
