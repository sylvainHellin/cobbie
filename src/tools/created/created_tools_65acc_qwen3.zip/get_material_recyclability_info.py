
import ifcopenshell
import ifcopenshell.util.element
from typing import Dict, List, Any, Optional

def get_material_recyclability_info(
    ifc_file_path: str,
    material_names: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Extract recyclability information for materials in an IFC model.
    
    This function searches for specific recyclability properties in the IFC model.
    If no specific data is found, it provides general recyclability information
    for common building materials.
    
    Args:
        ifc_file_path (str): Path to the IFC file
        material_names (Optional[List[str]]): Specific material names to check 
            (if None, check all materials in the model)
    
    Returns:
        Dict[str, Any]: A dictionary containing:
            - 'model_data': List of materials with recyclability information found in the model
            - 'general_info': List of materials with general recyclability information
            - 'summary': A summary statement about the availability of recyclability information
            - 'recommendations': Suggestions for obtaining more detailed information if needed
    """
    
    # General recyclability information database
    general_recyclability_info = {
        "Concrete": {
            "recyclability": "High",
            "recycled_content": "0-100%",
            "recyclability_description": "Concrete can be crushed and reused as aggregate in new concrete, road base, or fill material.",
            "confidence": "High",
            "source": "General construction industry knowledge"
        },
        "Steel": {
            "recyclability": "Very High",
            "recycled_content": "25-95%",
            "recyclability_description": "Steel is one of the most recycled materials globally, with virtually unlimited recycling potential without quality loss.",
            "confidence": "High",
            "source": "General construction industry knowledge"
        },
        "Aluminum": {
            "recyclability": "Very High",
            "recycled_content": "30-95%",
            "recyclability_description": "Aluminum can be recycled indefinitely without losing its properties, requiring only 5% of the energy needed to produce primary aluminum.",
            "confidence": "High",
            "source": "General construction industry knowledge"
        },
        "Copper": {
            "recyclability": "Very High",
            "recycled_content": "20-90%",
            "recyclability_description": "Copper maintains its properties through recycling and is highly valued in the secondary market.",
            "confidence": "High",
            "source": "General construction industry knowledge"
        },
        "Plastic": {
            "recyclability": "Variable",
            "recycled_content": "0-50%",
            "recyclability_description": "Recyclability depends on plastic type; some types are easily recycled while others are difficult or not economically viable.",
            "confidence": "Medium",
            "source": "General construction industry knowledge"
        },
        "Wood": {
            "recyclability": "High",
            "recycled_content": "0-30%",
            "recyclability_description": "Wood can be reused, recycled into engineered products, or used as biomass fuel.",
            "confidence": "High",
            "source": "General construction industry knowledge"
        },
        "Glass": {
            "recyclability": "High",
            "recycled_content": "10-90%",
            "recyclability_description": "Glass can be recycled indefinitely without loss in quality or purity.",
            "confidence": "High",
            "source": "General construction industry knowledge"
        },
        "Brick": {
            "recyclability": "Medium",
            "recycled_content": "0-20%",
            "recyclability_description": "Bricks can be crushed for use as aggregate or road base, but recycling is less common than reuse.",
            "confidence": "Medium",
            "source": "General construction industry knowledge"
        },
        "Insulation - Rigid insulation": {
            "recyclability": "Low",
            "recycled_content": "0-10%",
            "recyclability_description": "Rigid insulation materials like foam boards are difficult to recycle due to their chemical composition and contamination issues.",
            "confidence": "Medium",
            "source": "General construction industry knowledge"
        },
        "Plasterboard": {
            "recyclability": "Medium",
            "recycled_content": "0-15%",
            "recyclability_description": "Plasterboard can be recycled to make new plasterboard or used in cement production, but requires separation of paper and gypsum.",
            "confidence": "Medium",
            "source": "General construction industry knowledge"
        },
        "Metal - Stud Layer": {
            "recyclability": "Very High",
            "recycled_content": "25-95%",
            "recyclability_description": "Metal studs are typically made of steel and can be recycled indefinitely without quality loss.",
            "confidence": "High",
            "source": "General construction industry knowledge"
        }
    }

    # Material name variations mapping
    material_name_variations = {
        "concrete": ["concrete", "cement"],
        "steel": ["steel", "metal", "structural steel"],
        "aluminum": ["aluminum", "aluminium"],
        "copper": ["copper"],
        "plastic": ["plastic", "pvc", "upvc", "polyvinyl chloride"],
        "wood": ["wood", "timber", "lumber"],
        "glass": ["glass"],
        "brick": ["brick", "masonry"],
        "insulation": ["insulation", "rigid insulation"],
        "plasterboard": ["plasterboard", "drywall", "gypsum board"],
        "metal": ["metal", "stud"]
    }

    # Load the IFC file
    ifc_file = ifcopenshell.open(ifc_file_path)
    
    # Get all materials in the model or filter by specified names
    if material_names:
        # Filter materials by specified names
        all_materials = []
        for name in material_names:
            materials = ifc_file.by_type("IfcMaterial")
            matched_materials = [mat for mat in materials if mat.Name and name.lower() in mat.Name.lower()]
            all_materials.extend(matched_materials)
    else:
        # Get all materials
        all_materials = ifc_file.by_type("IfcMaterial")
    
    # Also get other material-related entities
    material_layer_sets = ifc_file.by_type("IfcMaterialLayerSet")
    material_layer_set_usages = ifc_file.by_type("IfcMaterialLayerSetUsage")
    material_lists = ifc_file.by_type("IfcMaterialList")
    
    # Combine all material entities
    all_material_entities = []
    all_material_entities.extend(all_materials)
    all_material_entities.extend(material_layer_sets)
    all_material_entities.extend(material_layer_set_usages)
    all_material_entities.extend(material_lists)
    
    # Search for specific recyclability properties in the model
    model_data = []
    general_info = []
    
    # Check each material entity for recyclability properties
    for entity in all_material_entities:
        # Get entity name
        entity_name = getattr(entity, 'Name', f"Unnamed {entity.is_a()}")
        if not entity_name:
            entity_name = f"Unnamed {entity.is_a()}"
        
        # Get properties of the entity
        properties = ifcopenshell.util.element.get_psets(entity)
        
        # Look for recyclability-related properties
        recyclability_props = {}
        if properties:
            for prop_set_name, prop_set in properties.items():
                for prop_name, prop_value in prop_set.items():
                    if any(keyword in prop_name.lower() for keyword in ['recycle', 'recyclability', 'recycled', 'sustainability', 'environmental']):
                        recyclability_props[f"{prop_set_name}.{prop_name}"] = prop_value
        
        # If we found recyclability properties, add to model_data
        if recyclability_props:
            model_data.append({
                "material_name": entity_name,
                "recyclability_data": recyclability_props,
                "source": "IFC Model",
                "confidence": "High"
            })
    
    # Get list of all material names in the model for general info
    model_material_names = []
    for entity in all_materials:
        if hasattr(entity, 'Name') and entity.Name:
            model_material_names.append(entity.Name)
    
    # If no specific recyclability data was found, provide general information
    if not model_data:
        # For each material in the model, try to match with general info
        for material_name in model_material_names:
            # Try to find matching general info
            matched = False
            for general_name, info in general_recyclability_info.items():
                # Check if material name matches general name or its variations
                if (general_name.lower() in material_name.lower() or 
                    material_name.lower() in general_name.lower()):
                    general_info.append({
                        "material_name": material_name,
                        "recyclability_data": info,
                        "source": "General Information",
                        "confidence": info["confidence"]
                    })
                    matched = True
                    break
            
            # If no direct match, try variations
            if not matched:
                for general_type, variations in material_name_variations.items():
                    if any(variation in material_name.lower() for variation in variations):
                        # Get the corresponding general info
                        for general_name, info in general_recyclability_info.items():
                            if general_type in general_name.lower():
                                general_info.append({
                                    "material_name": material_name,
                                    "recyclability_data": info,
                                    "source": "General Information",
                                    "confidence": info["confidence"]
                                })
                                matched = True
                                break
                    if matched:
                        break
            
            # If still no match, add with low confidence
            if not matched:
                general_info.append({
                    "material_name": material_name,
                    "recyclability_data": {
                        "recyclability": "Unknown",
                        "recycled_content": "Unknown",
                        "recyclability_description": "No specific recyclability information available for this material type.",
                        "confidence": "Low",
                        "source": "General construction industry knowledge"
                    },
                    "source": "General Information",
                    "confidence": "Low"
                })
    
    # Create summary
    if model_data:
        summary = f"Found specific recyclability information for {len(model_data)} materials directly in the IFC model."
    elif general_info:
        summary = f"No specific recyclability information found in the model. Providing general recyclability information for {len(general_info)} materials."
    else:
        summary = "No materials found in the model or no recyclability information available."
    
    # Create recommendations
    recommendations = []
    if not model_data:
        recommendations.append("To improve recyclability tracking, add specific recyclability properties to materials in your BIM authoring software using property sets like 'Pset_MaterialRecyclability' or similar.")
        recommendations.append("Consider using BIM authoring software features that support sustainability and environmental impact data.")
        recommendations.append("For more accurate data, consult material manufacturers' environmental product declarations (EPDs).")
    
    return {
        "model_data": model_data,
        "general_info": general_info,
        "summary": summary,
        "recommendations": recommendations
    }
